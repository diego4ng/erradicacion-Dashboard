<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class MetodoErradicacion extends Model
{
    protected $connection = 'mysql2';
    protected $table = "c_merradica";
}
