<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class Validation extends Model
{
    protected $connection = 'mysql2';
    protected $table = "o_validacion";

}
