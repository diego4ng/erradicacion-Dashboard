<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class ZonaMilitar extends Model
{
    //
}
