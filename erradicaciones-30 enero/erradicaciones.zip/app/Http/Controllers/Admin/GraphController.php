<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Admin\Plantio;
use App\Models\Admin\TipoPlantio;
use App\Models\Admin\Presentacion;
use App\Models\Admin\Estado;
use App\Models\Admin\Register;
use App\Models\Admin\Dependencia;
use Illuminate\Support\Facades\DB;

class GraphController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data_plantios = Plantio::
            with(['tipoPlantio'])
            ->select('c_i_tplantio', DB::raw('COUNT(c_i_tplantio) as count'))
            ->groupBy('c_i_tplantio')
            ->orderBy('count', 'desc')
            ->get()
            ->toArray();

        $data_presentacion = Plantio::
            with(['presentacion'])
            ->select('c_i_presentacion', DB::raw('COUNT(c_i_presentacion) as count'))
            ->groupBy('c_i_presentacion')
            ->orderBy('count', 'desc')
            ->get()
            ->toArray();

        $data_area = Plantio::
            with(['areaErradicada'])
            ->select('c_v_evento','c_i_tplantio')
            ->get()
            ->toArray();

        $data_institucion_erradica = Plantio::
            with(['institucion_erradica'])
            //->select('c_v_evento','institución_erradica.c_i_dependencia')
            ->get()
            ->toArray();

        $catalogo_estados = Estado::orderBy('ID_ESTADO')->pluck('NOMBRE', 'ID_ESTADO')->toArray();
        $tipos_plantio = TipoPlantio::orderBy('c_i_tplantio')->pluck('d_v_tplantio', 'c_i_tplantio')->toArray();
        $tipos_presentacion = Presentacion::orderBy('c_i_presentacion')->pluck('d_v_presentacion', 'c_i_presentacion')->toArray();
        $tipos_institucion = Dependencia::orderBy('c_i_dependencia')->pluck('d_v_dependencia', 'c_i_dependencia')->toArray();

        return view('admin.graphs.graph', compact('data_plantios','data_presentacion','data_area','tipos_plantio','catalogo_estados','data_institucion_erradica','tipos_institucion'));
    }

    public function graph_filter(Request $request)
    {

        $fecha_inicial = $request['startDate'];
        $fecha_final = $request['endDate'];
        $fecha = date($fecha_final);
        $nuevafecha = strtotime ( '+1 day' , strtotime ( $fecha ) ) ;
        $nuevafechafinal = date ( 'Y-m-j' , $nuevafecha );

        if (isset($request['estado_ids'])) {

            if ($fecha_inicial <= $fecha_final) {

                $id_eventos = Register::whereIn('c_i_estado', $request['estado_ids'])
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->get('c_v_evento')
                    ->toArray();

                $data_plantios = Plantio::
                    with(['tipoPlantio'])
                    ->select('c_i_tplantio', DB::raw('COUNT(c_i_tplantio) as count'))
                    ->groupBy('c_i_tplantio')
                    ->orderBy('c_i_tplantio', 'asc')
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->whereIn('c_v_evento', $id_eventos)
                    ->get()
                    ->toArray();

                $data_presentacion = Plantio::
                    with(['presentacion'])
                    ->select('c_i_presentacion', DB::raw('COUNT(c_i_presentacion) as count'))
                    ->groupBy('c_i_presentacion')
                    ->orderBy('c_i_presentacion', 'asc')
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->whereIn('c_v_evento', $id_eventos)
                    ->get()
                    ->toArray();

                $data_area = Plantio::
                    with(['areaErradicada'])
                    ->select('c_v_evento','c_i_tplantio')
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->whereIn('c_v_evento', $id_eventos)
                    ->get()
                    ->toArray();

                $data_institucion_erradica = Plantio::
                    with(['institucion_erradica'])
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->whereIn('c_v_evento', $id_eventos)
                    ->get()
                    ->toArray();
            }else{

                $id_eventos = Register::whereIn('c_i_estado', $request['estado_ids'])
                    ->get('c_v_evento')
                    ->toArray();

                $data_plantios = Plantio::
                    with(['tipoPlantio'])
                    ->select('c_i_tplantio', DB::raw('COUNT(c_i_tplantio) as count'))
                    ->groupBy('c_i_tplantio')
                    ->orderBy('c_i_tplantio', 'asc')
                    ->whereIn('c_v_evento', $id_eventos)
                    ->get()
                    ->toArray();

                $data_presentacion = Plantio::
                    with(['presentacion'])
                    ->select('c_i_presentacion', DB::raw('COUNT(c_i_presentacion) as count'))
                    ->groupBy('c_i_presentacion')
                    ->orderBy('c_i_presentacion', 'asc')
                    ->whereIn('c_v_evento', $id_eventos)
                    ->get()
                    ->toArray();

                $data_area = Plantio::
                    with(['areaErradicada'])
                    ->select('c_v_evento','c_i_tplantio')
                    ->whereIn('c_v_evento', $id_eventos)
                    ->get()
                    ->toArray();

                $data_institucion_erradica = Plantio::
                    with(['institucion_erradica'])
                    ->whereIn('c_v_evento', $id_eventos)
                    ->get()
                    ->toArray();
            }

        }else{

            if ($fecha_inicial <= $fecha_final) {

                $data_plantios = Plantio::
                    with(['tipoPlantio'])
                    ->select('c_i_tplantio', DB::raw('COUNT(c_i_tplantio) as count'))
                    ->groupBy('c_i_tplantio')
                    ->orderBy('c_i_tplantio', 'asc')
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->get()
                    ->toArray();

                $data_presentacion = Plantio::
                    with(['presentacion'])
                    ->select('c_i_presentacion', DB::raw('COUNT(c_i_presentacion) as count'))
                    ->groupBy('c_i_presentacion')
                    ->orderBy('c_i_presentacion', 'asc')
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->get()
                    ->toArray();

                $data_area = Plantio::
                    with(['areaErradicada'])
                    ->select('c_v_evento','c_i_tplantio')
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->get()
                    ->toArray();

                $data_institucion_erradica = Plantio::
                    with(['institucion_erradica'])
                    ->where('f_t_registro', '>=', $fecha_inicial)
                    ->where('f_t_registro', '<=', $nuevafechafinal)
                    ->get()
                    ->toArray();

            }else{

                $data_plantios = Plantio::
                    with(['tipoPlantio'])
                    ->select('c_i_tplantio', DB::raw('COUNT(c_i_tplantio) as count'))
                    ->groupBy('c_i_tplantio')
                    ->orderBy('c_i_tplantio', 'asc')
                    ->get()
                    ->toArray();

                $data_presentacion = Plantio::
                    with(['presentacion'])
                    ->select('c_i_presentacion', DB::raw('COUNT(c_i_presentacion) as count'))
                    ->groupBy('c_i_presentacion')
                    ->orderBy('c_i_presentacion', 'asc')
                    ->get()
                    ->toArray();

                $data_area = Plantio::
                    with(['areaErradicada'])
                    ->select('c_v_evento','c_i_tplantio')
                    ->get()
                    ->toArray();

                $data_institucion_erradica = Plantio::
                    with(['institucion_erradica'])
                    ->get()
                    ->toArray();
                }
        }

        $catalogo_estados = Estado::orderBy('ID_ESTADO')->pluck('NOMBRE', 'ID_ESTADO')->toArray();
        $tipos_plantio = TipoPlantio::orderBy('c_i_tplantio')->pluck('d_v_tplantio', 'c_i_tplantio')->toArray();
        $tipos_presentacion = Presentacion::orderBy('c_i_presentacion')->pluck('d_v_presentacion', 'c_i_presentacion')->toArray();
        $tipos_institucion = Dependencia::orderBy('c_i_dependencia')->pluck('d_v_dependencia', 'c_i_dependencia')->toArray();

        return view('admin.graphs.graph', compact('data_plantios','data_presentacion','data_area','tipos_plantio','tipos_presentacion','catalogo_estados','data_institucion_erradica','tipos_institucion'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
